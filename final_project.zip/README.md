# User Authentication With Passport.js

- In this post I’ll demonstrate how to add user authentication to Node.js with Passport.js. 
- View the blog post here: http://mherman.org/blog/2013/11/11/user-authentication-with-passport-dot-js/



